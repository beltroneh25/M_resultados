# M_resultados
matriz triangular superior
